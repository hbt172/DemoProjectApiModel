import UIKit
import Alamofire

let DEVICE_TYPE_ANDROID    = "1"
let DEVICE_TYPE_IOS        = "2"

public enum APIRouter: URLRequestConvertible {
    
    static var baseURLPath:String {
        get {
            return "BaseUrlPath"

        }
    }

	// ----------------------------------------------------------------------------
	// MARK: - API End Points
	// ----------------------------------------------------------------------------
    case performClientLogin(email: String, password: String)
    case getClientEvents(clientID:String)
    case getClientEventDetails(eventId:String)
    case resetPassword(email:String)
    case cloneClientEvent(eventId:String, clientID: String)
    
    
	// ----------------------------------------------------------------------------
	// MARK: - HTTP Types
	// ----------------------------------------------------------------------------
	private var httpMethod: HTTPMethod {
		switch self {
            case .performClientLogin,
                 .getClientEvents,
                 .getClientEventDetails,
                 .resetPassword,
                 .cloneClientEvent:
                return .post
        }
	}
	
	// ----------------------------------------------------------------------------
	// MARK: - API Paths
	// ----------------------------------------------------------------------------
	private var apiPath: String {
        switch self {
        case .performClientLogin:
            return "client/login"
        case .getClientEvents:
            return "event/list"
        case .getClientEventDetails:
            return "event/detail"
        case .resetPassword:
            return "client/forgetpassword"
        case .cloneClientEvent:
            return "event/clone"
        }
	}
	
	// ----------------------------------------------------------------------------
	// MARK: - Parameters
	// ----------------------------------------------------------------------------
	private var parameters: Dictionary<String, Any> {
		switch self {
		case .performClientLogin(let email, let password):
			return ["email": email,
                    "password": password
                    ]
        case .getClientEvents(let clientID):
            return ["client_encrypt_id": clientID]
        case .getClientEventDetails(let eventId):
            return ["event_encrypt_id":eventId]
        case .resetPassword(let email):
            return ["email": email]
        case .cloneClientEvent(let eventId, let clientID):
            return ["event_encrypt_id": eventId,
                    "client_encrypt_id": clientID]
        }
	}
    
	// ----------------------------------------------------------------------------
	// MARK: - URL Request
	// ----------------------------------------------------------------------------
	public func asURLRequest() throws -> URLRequest {
		let parameters = self.parameters
        let url = try APIRouter.baseURLPath.asURL()
		var request = URLRequest(url: url.appendingPathComponent(self.apiPath))
		request.httpMethod = self.httpMethod.rawValue
//        request.setValue(APIRouter.companyID, forHTTPHeaderField: "companyID")
//        let authenticationString = AUTH_USERNAME + ":" + AUTH_PASSWORD
//        let authData = authenticationString.data(using: String.Encoding.utf8)!
//        let authValue = authData.base64EncodedString(options: Data.Base64EncodingOptions.endLineWithCarriageReturn)
//        let authHeader = "Basic " + authValue
//        request.setValue(authHeader, forHTTPHeaderField: "Authorization")
        let boundary = generateBoundaryString()
        let contentType = "multipart/form-data; boundary=" + boundary
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")
        request.httpBody = createBody(withBoundary: boundary, parameters: parameters)
        return try request.asURLRequest()
	}

    public func generateBoundaryString() -> String {
        return "Boundary-" + NSUUID().uuidString
    }
    
    public func createBody(withBoundary boundary: String?, parameters: [String : Any]?) -> Data? {
        var httpBody = Data()
        
        // add params (all params are strings)
        
        for (key, Value) in parameters! {
            if let anEncoding = "--\(boundary ?? "")\r\n".data(using: String.Encoding.utf8) {
                httpBody.append(anEncoding)
            }
            if let anEncoding = "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: String.Encoding.utf8) {
                httpBody.append(anEncoding)
            }
            if let anEncoding = "\(Value)\r\n".data(using: String.Encoding.utf8) {
                httpBody.append(anEncoding)
            }
        }
        if let anEncoding = "--\(boundary ?? "")--\r\n".data(using: String.Encoding.utf8) {
            httpBody.append(anEncoding)
        }
        return httpBody
    }
    
}
