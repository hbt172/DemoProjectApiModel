import Foundation
import SwiftyJSON
// TODO: needs to be updated
// TODO: Consider using struct instead of parameters for completion

protocol APIManagerProtocol {
	
	// ----------------------------------------------------------------------------
	// MARK: - Authentication
	// ----------------------------------------------------------------------------
//    func performClientLogin(with email:String, password:String, completion: @escaping (_ request: URLRequest?, _ result: JSON, _ error: NSError?) -> ())
//    
//    // ----------------------------------------------------------------------------
//    // MARK: - Client Events
//    // ----------------------------------------------------------------------------
//    func getClientEvents(clientID: String, completion: @escaping (Events?, NSError?) -> ())
//    func getClientEventDetails(eventID: String, completion: @escaping (Detail?, NSError?) -> ())
//    func cloneEvent(eventID: String, clientID: String, completion: @escaping (Event?, NSError?) -> ())
    
    func PerformLogin(email: String, password: String, completion: @escaping (LoginDetials?, NSError?) -> ())
}
