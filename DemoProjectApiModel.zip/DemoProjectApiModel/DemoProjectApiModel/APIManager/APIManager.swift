import Foundation
import Alamofire
import SwiftyJSON

enum APIResponseKeys: String {
    
    // MARK: Auth Token
    case responseMessage = "Message"
    case authToken = "AuthToken"
}

class APIManager {
    
    // ----------------------------------------------------------------------------
    // MARK: - Properties
    // ----------------------------------------------------------------------------
    static let errorDomain = "com.vsnap.error"
    
    var userEmail: String?
    var userPassword: String?
    var deviceToken: String?
    var deviceType: String?
    var deviceUniqueId: String?
    
    
    public static let sharedInstance = APIManager()
    
    private init() {
        
    }
}

// ----------------------------------------------------------------------------
// MARK: - API Manager Protocol
// ----------------------------------------------------------------------------
extension APIManager: APIManagerProtocol {
    
    func errorMessageFor(response: DataResponse<Any>) -> String? {
        let stringData = String(data: response.data!, encoding: .utf8)
        let arr = stringData?.components(separatedBy: "\"")
        
        if let arr = arr, (arr.count - 2) >= 0 {
            let responseMessage = arr[arr.count - 2]
            return responseMessage
        }
        
        return nil
    }
    
    // ----------------------------------------------------------------------------
    // MARK: - Authentication
    // ----------------------------------------------------------------------------
    
 
    
    func PerformLogin(email: String, password: String, completion: @escaping (LoginDetials?, NSError?) -> ()) {
        let request = Alamofire.request(APIRouter.performClientLogin(email: email, password: password))
        startRequest(request) { (req, data, error) in
            if let data = data {
                do {
                    let json = try JSON.init(data: data)
                    if json["status"].boolValue == true {
                        let eventList = try JSONDecoder().decode(LoginData.self, from: data)
                        completion(eventList.data, nil)
                    } else {
                        let err = NSError.init(domain: kServerErrorDomain, code: kServerErrorCode, userInfo: [NSLocalizedDescriptionKey:json["message"].description])
                        completion(nil, err)
                    }
                } catch let err {
                    let e = NSError.init(domain: kResponseErrorDomain, code: kResponseErrorCode, userInfo: [NSLocalizedDescriptionKey:err.localizedDescription])
                    completion(nil, e)
                }
            } else {
                let err = NSError.init(domain: kCustomErrorDomain, code: kCustomErrorCode, userInfo: [NSLocalizedDescriptionKey:kSomethingWrong])
                completion(nil , err)
            }
        }
    }
    
    func startRequest(_ dataRequest:DataRequest,completion: @escaping (URLRequest?, Data?, NSError?) -> ()) {
        dataRequest.responseData { (response) in            if let error = response.error {
                let err = NSError.init(domain: kResponseErrorDomain, code: kResponseErrorCode, userInfo: [NSLocalizedDescriptionKey:error.localizedDescription])
                completion(response.request, nil, err)
            } else {
                if let data = response.data {
                    do {
                        let json = try JSON.init(data: data)
                        if json["status"].boolValue == true {
                            completion(response.request, data, nil)
                        } else {
                            let err = NSError.init(domain: kServerErrorDomain, code: kServerErrorCode, userInfo: [NSLocalizedDescriptionKey:json["message"].description])
                            completion(response.request, nil, err)
                        }
                    } catch let jsonErr {
                        let err = NSError.init(domain: kCustomErrorDomain, code: kCustomErrorCode, userInfo: [NSLocalizedDescriptionKey:kSomethingWrong])
                        completion(response.request, nil, err)
                    }
                } else {
                    let err = NSError.init(domain: kCustomErrorDomain, code: kCustomErrorCode, userInfo: [NSLocalizedDescriptionKey:kSomethingWrong])
                    completion(response.request, nil, err)
                }
            }
        }
    }
}
