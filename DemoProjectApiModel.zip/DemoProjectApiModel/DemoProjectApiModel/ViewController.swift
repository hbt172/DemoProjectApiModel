
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnLoginClick(_ sender: Any) {
        APIManager.sharedInstance.PerformLogin(email: txtEmail.text!, password: txtPassword.text!) { (details, error) in
            if let error = error {
                   print(error.localizedDescription)
            } else {
                DispatchQueue.main.async {
                    if let detail = details {
                            print(detail.client_name)
                    }
                }
            }
        }
    }
}

