

import Foundation

let kCustomErrorDomain      = "customErrorDomain"
let kCustomErrorCode       = 9865

let kServerErrorDomain      = "ServerErrorDomain"
let kServerErrorCode       = 9855

let kResponseErrorDomain      = "ResponseErrorDomain"
let kResponseErrorCode       = 9855

let kSomethingWrong             = "Something went wrong. Please try again later."
